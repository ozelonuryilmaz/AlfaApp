//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

struct ___VARIABLE_moduleName___Params: ICoordinatorParams {
    
}
