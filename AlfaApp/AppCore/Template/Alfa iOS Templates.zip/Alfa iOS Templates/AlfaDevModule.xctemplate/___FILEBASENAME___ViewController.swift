//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import UIKit

final class ___VARIABLE_moduleName___ViewController: AlfaBaseViewController<___VARIABLE_moduleName___RootView> {
    
    // MARK: Injection
    private let viewModel: I___VARIABLE_moduleName___ViewModel
    
    // MARK: Init
    init(viewModel: I___VARIABLE_moduleName___ViewModel) {
        self.viewModel = viewModel
        super.init()
    }
    
    override func setupView() {
        
    }
    
    override func initialComponents() {
        observeViewState()
        listenErrorState()
    }
    
    /*override func setLayoutStyle() -> (top: EdgeLayoutStyle, leading: EdgeLayoutStyle, bottom: EdgeLayoutStyle, trailing: EdgeLayoutStyle) {
     return (.safeArea, .safeArea, .safeArea, .safeArea)
     }*/
    
    // MARK: Bindings
    private func observeViewState() {
        viewModel.viewState
            .compactMap { $0 }
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                self?.handle(state: state)
            }
            .store(in: &cancelBag)
    }
    
    private func handle(state: ___VARIABLE_moduleName___ViewState) {
        switch state {
        case .showLoadingProgress(let isProgress):
            self.playNativeLoading(isLoading: isProgress)
            
        }
    }
    
    private func listenErrorState() {
        //observeErrorState(errorState: viewModel.errorState)
    }
}

// MARK: Props
private extension ___VARIABLE_moduleName___ViewController {
    
}
