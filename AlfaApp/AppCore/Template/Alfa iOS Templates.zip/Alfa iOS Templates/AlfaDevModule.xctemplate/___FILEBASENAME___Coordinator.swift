//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

INavigationCoordinator veya IPresentationCoordinator seçiniz
protocol I___VARIABLE_moduleName___Coordinator: INavigationCoordinator / IPresentationCoordinator {
    
}

final class ___VARIABLE_moduleName___Coordinator: NavigationCoordinator / PresentationCoordinator, I___VARIABLE_moduleName___Coordinator {
    
    override func start() {
        let controller = ___VARIABLE_moduleName___Builder.generate(coordinator: self)
        //controller.modalPresentationStyle = .fullScreen
        showScreen(viewController: controller)
    }
    
}
