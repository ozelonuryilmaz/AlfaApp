//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

protocol I___VARIABLE_moduleName___ViewModel: AnyObject {
    
    var viewState: ScreenStateSubject<___VARIABLE_moduleName___ViewState> { get }
    var errorState: ErrorStateSubject { get }
    
    init(repository: I___VARIABLE_moduleName___Repository,
         coordinator: I___VARIABLE_moduleName___Coordinator,
         vmLogic: I___VARIABLE_moduleName___VMLogic)
}

final class ___VARIABLE_moduleName___ViewModel: BaseViewModel, I___VARIABLE_moduleName___ViewModel {
    
    // MARK: Definitions
    private let repository: I___VARIABLE_moduleName___Repository
    private let coordinator: I___VARIABLE_moduleName___Coordinator
    private var vmLogic: I___VARIABLE_moduleName___VMLogic
    
    // MARK: Props
    var viewState = ScreenStateSubject<___VARIABLE_moduleName___ViewState>(nil)
    var errorState = ErrorStateSubject(nil)
    
    // MARK: Initiliazer
    required init(repository: I___VARIABLE_moduleName___Repository,
                  coordinator: I___VARIABLE_moduleName___Coordinator,
                  vmLogic: I___VARIABLE_moduleName___VMLogic) {
        self.repository = repository
        self.coordinator = coordinator
        self.vmLogic = vmLogic
        super.init()
    }
    
}


// MARK: Service
internal extension ___VARIABLE_moduleName___ViewModel {
    
}

// MARK: States
internal extension ___VARIABLE_moduleName___ViewModel {
    
    // MARK: View State
    func viewStateShowLoadingProgress(isProgress: Bool) {
        viewState.value = .showLoadingProgress(isProgress: isProgress)
    }
    
}

// MARK: Coordinate
internal extension ___VARIABLE_moduleName___ViewModel {
    
}

enum ___VARIABLE_moduleName___ViewState {
    case showLoadingProgress(isProgress: Bool)
}
