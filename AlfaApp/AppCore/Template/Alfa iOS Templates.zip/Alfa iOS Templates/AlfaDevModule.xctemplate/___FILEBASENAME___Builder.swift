//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

enum ___VARIABLE_moduleName___Builder {
    
    static func generate(coordinator: I___VARIABLE_moduleName___Coordinator) -> ___VARIABLE_moduleName___ViewController {
        
        let repository: I___VARIABLE_moduleName___Repository = ___VARIABLE_moduleName___Repository()
        let vmLogic: I___VARIABLE_moduleName___VMLogic = ___VARIABLE_moduleName___VMLogic()
        
        let viewModel: I___VARIABLE_moduleName___ViewModel = ___VARIABLE_moduleName___ViewModel(
            repository: repository,
            coordinator: coordinator,
            vmLogic: vmLogic
        )
        
        return ___VARIABLE_moduleName___ViewController(
            viewModel: viewModel
        )
    }
}
