//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

protocol I___VARIABLE_moduleName___Repository: AnyObject {
    
}

final class ___VARIABLE_moduleName___Repository: BaseRepository, I___VARIABLE_moduleName___Repository {
    
}
