//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ AlfaApp IOS Development Team. All rights reserved.
//

import Foundation

protocol I___VARIABLE_moduleName___VMLogic {
    
    init(data: ___VARIABLE_moduleName___Params)
    
}

struct ___VARIABLE_moduleName___VMLogic: I___VARIABLE_moduleName___VMLogic {
    
    // MARK: Definitions
    
    // MARK: Initialize
    init(data: ___VARIABLE_moduleName___Params) {
        
    }
    
    // MARK: Props
}

// MARK: Props
extension ___VARIABLE_moduleName___VMLogic {
    
}
