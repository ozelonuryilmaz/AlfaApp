//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

@testable import AlfaApp

enum ___VARIABLE_moduleName___MockBuilder {

    static func generate(passData: ___VARIABLE_moduleName___PassData) -> ___VARIABLE_moduleName___MockViewController {

        let coordinator = ___VARIABLE_moduleName___MockCoordinator()
        let repository = ___VARIABLE_moduleName___MockRepository()
        let uiModel = ___VARIABLE_moduleName___MockUIModel(data: passData)
        let viewModel = ___VARIABLE_moduleName___MockViewModel(repository: repository, coordinator: coordinator, uiModel: uiModel)

        return ___VARIABLE_moduleName___MockViewController(viewModel: viewModel)
    }
}
