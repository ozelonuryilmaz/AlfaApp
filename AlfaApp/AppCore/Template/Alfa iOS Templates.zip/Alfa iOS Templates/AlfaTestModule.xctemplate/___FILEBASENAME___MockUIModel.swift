//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

@testable import AlfaApp

struct ___VARIABLE_moduleName___MockUIModel: I___VARIABLE_moduleName___UIModel {

    // MARK: Definitions

    // MARK: Initialize
    init(data: ___VARIABLE_moduleName___PassData) {

    }

    // MARK: Computed Props
}

// MARK: Props
extension ___VARIABLE_moduleName___MockUIModel {

}
