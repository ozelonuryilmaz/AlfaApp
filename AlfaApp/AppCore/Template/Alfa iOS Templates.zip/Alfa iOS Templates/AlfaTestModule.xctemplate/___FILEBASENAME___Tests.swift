//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

import XCTest
@testable import AlfaApp

final class ___VARIABLE_moduleName___Tests: XCTestCase {

    var viewController: ___VARIABLE_moduleName___MockViewController!

    override func setUpWithError() throws {
        let data = ___VARIABLE_moduleName___PassData()
        viewController = ___VARIABLE_moduleName___MockBuilder.generate(passData: data)
        try super.setUpWithError()
    }

    override func tearDownWithError() throws {
        try super.tearDownWithError()
        viewController = nil
    }
}

/*
Testleri üç adıma ayırın:
   1. [Given / Arrange] test verilerini hazırlayın
   2. [When / Act]      test edilecek fonksiyonu çağırın
   3. [Then / Assert]   sonucu beklenen değerle karşılaştırın.
*/

// MARK: ViwController Tests
internal extension ___VARIABLE_moduleName___Tests {

    // Sample:
    /* ViewDidLoad Func
    func test_ViewDidLoad() {
        // [Given]
        XCTAssertFalse(viewController.invokedVisibilityMessageView)
        XCTAssertFalse(viewController.invokedRescanAfterAlert)

        // [When]
        viewController.viewDidload()

        // [Then]
        XCTAssertTrue(viewController.invokedVisibilityMessageView)
        XCTAssertTrue(viewController.invokedRescanAfterAlert)
    }*/
}


// MARK: ViewModel Tests
internal extension ___VARIABLE_moduleName___Tests {

}


// MARK: UIModel Tests
internal extension ___VARIABLE_moduleName___Tests {

    // Sample:
    /* A test method that checks the getDeeplinkUrl function with a valid code
     func test_GetDeeplinkUrlWithValidCode() {
        // [Given] a valid code with a deeplink parameter
        let code = "https://app.adjust.com/10k01up0?label=qr_code&deeplink=emlakjetapp://photo_galery?id=123&token=abc&limit=10"

        // [When] we call the getDeeplinkUrl function with the code
        let deeplink = viewController.viewModel.getDeeplinkUrl(from: code)

        // [Then] we expect the deeplink to be not nil and equal to the expected value
        XCTAssertNotNil(deeplink, "The deeplink should not be nil.")
        XCTAssertEqual(deeplink, "emlakjetapp://photo_galery?id=123&token=abc&limit=10", "The deeplink should match the expected value.")
    }*/

}


// MARK: Coordinator Tests
internal extension ___VARIABLE_moduleName___Tests {

}


// MARK: Repository Tests
internal extension ___VARIABLE_moduleName___Tests {

}
