//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

@testable import AlfaApp

final class ___VARIABLE_moduleName___MockCoordinator: I___VARIABLE_moduleName___Coordinator {

}
