//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

@testable import AlfaApp

protocol I___VARIABLE_moduleName___MockViewController {

    init(viewModel: I___VARIABLE_moduleName___MockViewModel)
}

final class ___VARIABLE_moduleName___MockViewController: I___VARIABLE_moduleName___MockViewController {

    // MARK: Inject
    private let viewModel: I___VARIABLE_moduleName___MockViewModel

    // MARK: Initializer
    required init(viewModel: I___VARIABLE_moduleName___MockViewModel) {
        self.viewModel = viewModel
        self.observeInitialComponents()
    }

    func viewDidload() {

    }

    func registerEvents() {

    }

    func observeInitialComponents() {
        /*viewModel._viewState.observeNext { [unowned self] state in
            switch state {
            case .showLoadingProgress(let isProgress):
                break
            }
        }*/
    }
}

// MARK: Props
private extension ___VARIABLE_moduleName___MockViewController {

}
