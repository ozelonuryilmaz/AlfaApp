//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

import Foundation

protocol I___VARIABLE_moduleName___MockRepository: AnyObject {

}

final class ___VARIABLE_moduleName___MockRepository: I___VARIABLE_moduleName___MockRepository {

}
