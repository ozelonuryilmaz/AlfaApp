//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

@testable import AlfaApp

protocol I___VARIABLE_moduleName___MockViewModel {

    var _viewState: ScreenStateSubject<___VARIABLE_moduleName___ViewState> { get }
    var _actionState: ScreenStateSubject<___VARIABLE_moduleName___ActionState> { get }

    init(repository: I___VARIABLE_moduleName___MockRepository,
         coordinator: ___VARIABLE_moduleName___MockCoordinator,
         uiModel: ___VARIABLE_moduleName___MockUIModel)
}

final class ___VARIABLE_moduleName___MockViewModel: I___VARIABLE_moduleName___MockViewModel {

    // MARK: Definitions
    private let repository: I___VARIABLE_moduleName___MockRepository
    private let coordinator: ___VARIABLE_moduleName___MockCoordinator
    private var uiModel: ___VARIABLE_moduleName___MockUIModel

    // MARK: Private Props
    private let viewState = ScreenStateSubject<___VARIABLE_moduleName___ViewState>()
    private let actionState = ScreenStateSubject<___VARIABLE_moduleName___ActionState>()

    // MARK: Public Props
    var _viewState: ScreenStateSubject<___VARIABLE_moduleName___ViewState> { viewState }
    var _actionState: ScreenStateSubject<___VARIABLE_moduleName___ActionState> { actionState }

    // MARK: Initiliazer
    required init(repository: I___VARIABLE_moduleName___MockRepository,
                  coordinator: ___VARIABLE_moduleName___MockCoordinator,
                  uiModel: ___VARIABLE_moduleName___MockUIModel) {
        self.repository = repository
        self.coordinator = coordinator
        self.uiModel = uiModel
    }

}


// MARK: Service
internal extension ___VARIABLE_moduleName___MockViewModel {

}

// MARK: UIModel
internal extension ___VARIABLE_moduleName___MockViewModel {

}

// MARK: Coordinate
internal extension ___VARIABLE_moduleName___MockViewModel {

}

// MARK: States
internal extension ___VARIABLE_moduleName___MockViewModel {

    // MARK: View State

    // MARK: Action State

}
